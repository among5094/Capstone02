const express = require('express');
const { ApolloServer } = require('apollo-server-express');
const { Neo4jGraphQL } = require('@neo4j/graphql');
const neo4j = require('neo4j-driver');

// Neo4j 드라이버 설정
const driver = neo4j.driver(
  'bolt://localhost:7687', // Neo4j uri
  neo4j.auth.basic('neo4j', 'dktlfhrl') // Neo4j 이름과 비밀번호
);

// GraphQL 스키마 정의
const typeDefs = `
    
    type User {
        id: ID!
        name: String!
        email: String!
        password: String!
        posts: [Post!]! @relationship(type: "CREATED", direction: OUT)
        comments: [Comment!]! @relationship(type: "WROTE", direction: OUT)
    }

    type Post {
      id: ID!
      title: String!
      content: String!
      userId: ID!
      author: User! @relationship(type: "CREATED", direction: IN)
    }

    type Comment {
      answer: String!
      author: User! @relationship(type: "WROTE", direction: IN)
      post: Post! @relationship(type: "ON_POST", direction: OUT)
    }

    type Mutation {
        signUp(name: String!, email: String!, password: String!): User
        postUp(title: String!, content: String!, userId: ID!): Post
        commentUp(answer: String!, postId: ID!, userId: ID!): Comment
    }

    type Query {
        login(email: String!, password: String!): User
        postList(title: String, content: String!): Post
    }
`;

const resolvers = {
  Query: {
    login: async (_, { email, password }, { driver }) => {
      const session = driver.session();
      try {
        const result = await session.run(
          'MATCH (u:User {email: $email, password: $password}) RETURN u',
          { email, password }
        );

        
        if (result.records.length > 0) {
          return result.records[0].get('u').properties;
        }

        throw new Error('이메일 또는 비밀번호가 잘못되었습니다.');
      } finally {
        session.close();
      }
    },
    postList: async (_, { title, content }, { driver }) => {
      const session = driver.session();
      try {
        const result = await session.run(
          'MATCH (p:Post {title: $title, content: $content}) RETURN p',
          { title, content}
        );

        if(result.records.length > 0) {
          return result.records[0].get('p').properties;
        }

        throw new Error('게시물이 잘못 되었습니다.');
      } finally {
        session.close();
      }
    }
    /*
    checkPost: async (_, { title, content }, { driver }) => {
      const session = driver.session();
      try {
        const result = await session.run(
          'MATCH (p:Post {title: $title, content: $content}) RETURN p',
          { title, content }
        );

        if(result.records.length > 0) {
          return result.records[0].get('p').properties;
        }

        throw new Error('제목 또는 내용이 잘못되었습니다.');
      } finally {
        session.close();
      }
    }*/
  },
  Mutation: {
    signUp: async (_, { name, email, password }, { driver }) => {
      const session = driver.session();

      try {
        const result = await session.run(
          'CREATE (u:User {id: randomUUID(), name: $name, email: $email, password: $password}) RETURN u',
          { name, email, password }
        );

        console.log('signUp result:', result);  // 디버깅: result 확인
      
      if (result.records.length > 0) {
        return result.records[0].get('u').properties;  // User의 속성을 반환
      }

      } finally {
        session.close();
      }
    },
    postUp: async (_, {title, content, userId}, {driver}) => {
      const session = driver.session();

      try {
        const result = await session.run(
          `
          MATCH (u:User {id: $userId})
          CREATE (p:Post {id: randomUUID(), title: $title, content: $content})
          CREATE (u)-[:CREATED]->(p)
          RETURN p
          
          `,
          { title, content, userId }
        );

        console.log('postUp result:', result);  // 디버깅: result 확인

      if(result.records.length > 0) {
        return result.records[0].get('p').properties; // Post의 속성 반환
      }

      throw new Error('게시글 생성 실패');
      } finally {
        session.close();
      }
    },
    commentUp: async (_, {answer, postId, userId}, {driver}) => {
      const session = driver.session();

      try {
        const result = await session.run(
          `
          MATCH (u:User {id: $userId}), (p:Post {id: $postId})
          CREATE (c:Comment {id: randomUUID(), answer: $answer})
          CREATE (u)-[:WROTE]->(c)
          CREATE (c)-[:ON_POST]->(p)
          RETURN c
          `,
          {answer, postId, userId}
        );

        console.log('commentUp result:', result);

        if(result.records.length > 0) {
          return result.records[0].get('c').properties;
        }

        throw new Error('댓글 생성에 실패했습니다.');
      } finally {
        session.close();
      }
    }
  }
};

// Neo4jGraphQL 객체 생성
const neoSchema = new Neo4jGraphQL({ typeDefs, driver, resolvers });

const app = express();

// ApolloServer 설정
async function startServer() {
    try{
        const server = new ApolloServer({
        schema: await neoSchema.getSchema(),
        context: ({ req }) => ({ driver })
        });
      
        await server.start();
        server.applyMiddleware({ app });
  
         app.listen({ port: 4000 }, () => {
            console.log(`Server is running at http://localhost:4000${server.graphqlPath}`);
        });
    } catch (error) {
        console.error('Error starting the server:', error);
        process.exit(1);
        }
}
    

startServer();